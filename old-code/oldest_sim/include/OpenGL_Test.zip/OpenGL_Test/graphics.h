#ifndef GRAPHICS_H
#define GRAPHICS_H

#include <iostream>
#include <functional>
#include <vector>
#include <deque>
#include "glut.h"
#include "utils.h"

namespace Alex {
    const GLfloat PI = 3.1415932385f,
                  TWO_PI = 2.0 * PI,
                  PI_OVER_180 = 0.0174532925f,
                  POINT_SLICES = 12.0;

    GLfloat polarAngle(GLfloat dx, GLfloat dy);

    class Color {
    public:
        Color() {};
        Color(GLfloat red, GLfloat green, GLfloat blue) {
            RGB[0] = red;
            RGB[1] = green;
            RGB[2] = blue;
        };

        inline const GLfloat* getArray() const { return RGB; };

    private:
        GLfloat RGB[3];
    };

    class Primitive {
    public:
        virtual char *getType() const = 0;
        virtual void draw() const = 0;
        virtual void tick() = 0;
    };

    class Point: public Primitive {
    public:
        bool isDupe;

        Point() {};
        Point(GLfloat x, GLfloat y, const Color &color, GLfloat radius = 0.02): x(x), y(y), radius(radius), color(color) {};

        GLfloat normX(const Point &source) const { 
            GLfloat size = sqrt(pow(x - source.x, 2) + pow(y - source.y, 2)); 
            return (size != 0 ? (x - source.x) / size : 0); 
        };

        inline GLfloat distance(Point other) const { 
            return sqrt(pow(x - other.x, 2) + pow(y - other.y, 2));
        };
    		
        inline bool leftTurn(Point ptA, Point ptB) const {
            return ((ptA.x - x) * (ptB.y - y) - (ptB.x - x) * (ptA.y - y) < 0);
        };

        inline bool operator != (Point pt) const {
            return (x != pt.x || y != pt.y || radius != pt.radius);
        };

        inline bool operator < (const Point &pt) const {
            return ((y < pt.y) || ((y == pt.y) && (x < pt.x)));
        };

        inline char *getType() const { return "Point"; };

        void tick() {}; // do nothing

        void draw() const {
            GLfloat theta;

            glColor3fv(color.getArray());
            glBegin(GL_TRIANGLE_FAN);
                glVertex2f(x, y);
                for (unsigned int j = 0; j < POINT_SLICES; j++) {
                    theta = 360 * j * PI_OVER_180 / POINT_SLICES;
                    glVertex2f(x + radius * cos(theta), y + radius * sin(theta));
                    theta = 360 * (j + 1) * PI_OVER_180 / POINT_SLICES;
                    glVertex2f(x + radius * cos(theta), y + radius * sin(theta));
                }
            glEnd();
        };

        inline GLfloat X() const { return x; };
        inline GLfloat Y() const { return y; };
        inline GLfloat getRadius() const { return radius; };
        inline Color getColor() const { return color; };

        inline void setX(GLfloat x) { this->x = x; };
        inline void setY(GLfloat y) { this->y = y; };
        inline void setRadius(GLfloat radius) { this->radius = radius; };
        inline void setColor(const Color &color) { this->color = color; };

    protected:
        GLfloat x, y, radius;
        Color color;
    };

    class AnimatedPoint: public Point {
    public:
        AnimatedPoint(GLfloat x, GLfloat y, const Color &color, Random *rnd, GLfloat radius = 0.02): Point(x, y, color, radius) {
            rotRadius = rnd->get(0.05, 0.25);
            rotAngle = rnd->get(0.0, 2 * PI);

            rotCenterX = x - rotRadius * cos(rotAngle);
            rotCenterY = y - rotRadius * sin(rotAngle);

            rotAngleInc = rnd->get(0.05, 0.1);
            if (rnd->get0_1() > 0.5)
                rotAngleInc = -rotAngleInc;
        };

        inline char *getType() const { return "AnimatedPoint"; };

        void tick() {
            x = rotCenterX + rotRadius * cos(rotAngle);
            y = rotCenterY + rotRadius * sin(rotAngle);
            rotAngle += rotAngleInc;

            if (rotAngle > TWO_PI)
                rotAngle =- TWO_PI;
            else if (rotAngle < -TWO_PI)
                rotAngle =+ TWO_PI;
        };

    private:
        Random *rnd;

        GLfloat rotCenterX,
                rotCenterY,
                rotRadius,
                rotAngle,
                rotAngleInc;
    };

    struct polarSort: public std::binary_function<Point*, Point*, bool> {
    public:
        polarSort(): pole(NULL) {};

        inline void setPole(Point *pole) { this->pole = pole; };

        bool operator() (Point *arg1, Point *arg2) const {
            if (!pole)
                exit(0);
            else if (arg1 == pole)
                return true;
            else if (arg2 == pole)
                return false;
            else {
                GLfloat arg1Theta = polarAngle(arg1->X() - pole->X(), arg1->Y() - pole->Y());
                GLfloat arg2Theta = polarAngle(arg2->X() - pole->X(), arg2->Y() - pole->Y());

                if (arg1Theta == arg2Theta) {
                    if (pole->distance(*arg1) >= pole->distance(*arg2))
                        arg2->isDupe = true;
                    else
                        arg1->isDupe = true;
                    return arg2->isDupe;
                }
                else
                    return (arg1Theta < arg2Theta);
            }
        };
    private:
        Point *pole;
    };

    class PointStack: public std::stack<Point*> {
    public:
        Point* underTop() {
            if (c.size() > 1) {
                return (*(--(--c.end())));
            }
            else
                return NULL;
        }
    };

    Point* getLowestPoint(std::vector<Point*> objects) {
        if (!objects.size())
            return NULL;

        Point *min = *objects.begin(), *pt;
        for (std::vector<Point*>::iterator iter = objects.begin(); iter != objects.end(); ++iter) {
            pt = *iter;
            if (pt->Y() < min->Y() || (pt->Y() == min->Y() && pt->X() < min->X()))
                min = pt;
        }
        return min;
    };

    bool removePoint(GLfloat x, GLfloat y, std::vector<Point*> &points) {
        Point *pt;
        for (std::vector<Point*>::iterator iter = points.begin(); iter != points.end(); ++iter) {
            pt = *iter;
            if (pow(x - pt->X(), 2) + pow(y - pt->Y(), 2) <= pow(pt->getRadius(), 2)) {
                points.erase(iter);
                return true;
            }
        }
        return false;
    };

    GLfloat polarAngle(GLfloat dx, GLfloat dy) {
        GLfloat theta;
        if (dx == 0) {
            if (dy > 0) theta = PI / 2;
            else if (dy < 0) theta = 3 * PI / 2;
            else theta = 0;
        }
        else {
            theta = atan(dy / dx);
            if (dx > 0 && dy < 0)
                theta += 2 * PI;
            else if (dx < 0)
                theta += PI;
        }

        return theta;
    };
};

#endif