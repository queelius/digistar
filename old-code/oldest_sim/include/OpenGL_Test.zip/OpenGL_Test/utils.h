#ifndef UTILS_H
#define UTILS_H

#include <time.h>
#include <stack>

namespace Alex {
    class Random {
    public:
        Random(int c = 1, int a = 16389, int m = 1073741824, int X = NULL): c(c), a(a), m(m) {
            this->X = (X == NULL) ? seed() : X;
        };

        double get(double lo, double hi) { return lo + (hi - lo) * get0_1(); };

        double get0_1() {
            X = (a * X + c) % m;
            if (X < 0)
                X = -X;
            return (double)X / m;
        };

    private:
        int X, a, c, m;

        unsigned int seed() const {
          time_t now;
          time(&now);
          return (unsigned int)now;
        };
    };
};

#endif