// NOTE: look into pointer MEMORY LEAKS

#include <windows.h>
#include <cmath>
#include <iostream>
#include <vector>
#include <algorithm>
#include <stack>
#include <deque>
#include "glut.h"
#include "graphics.h"
#include "utils.h"
using namespace std;
using namespace Alex;

typedef Point* pt;
typedef vector<pt> ptArray;
typedef vector<pt>::iterator ptIter;

GLint currWindowSize[2] = {900, 600};	// window size in pixels
GLfloat windowWidth     = 3.0;			// resized window width
GLfloat windowHeight    = 2.0;			// resized window height

const GLint INIT_WINDOW_POSITION[2] = {100, 100};

void handleMouseEvent(int mouseButton, int mouseState, int mouseXPosition, int mouseYPosition);
void handleKeyEvent(unsigned char pressedKey, int mouseXPosition, int mouseYPosition);
void TimerFunction(int value);
void Display();
void ResizeWindow(GLsizei w, GLsizei h);

bool isLeftTurn(Point *a, Point *b, Point *c);
void doHull();

ptArray objects;
polarSort polar;
Random rnd;

bool IS_POINTS_ANIMATED = false;
bool IS_POINTS_VISIBLE = true;
bool IS_LINES_VISIBLE = false;
bool IS_HULL_VISIBLE = false;

int main(int argc, char **argv) {
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowPosition(INIT_WINDOW_POSITION[0], INIT_WINDOW_POSITION[1]);
	glutInitWindowSize(currWindowSize[0], currWindowSize[1]);
	glutCreateWindow("Testing");

	glutReshapeFunc(ResizeWindow);
	glutDisplayFunc(Display);
	glutMouseFunc(handleMouseEvent);
	glutKeyboardFunc(handleKeyEvent);
	glutTimerFunc(50, TimerFunction, 1);
	glutMainLoop();

	return 0;
}

void handleMouseEvent(int mouseButton, int mouseState, int mouseXPosition, int mouseYPosition) {
	if (mouseState == GLUT_DOWN && mouseButton == GLUT_LEFT_BUTTON) {
    	GLfloat x = windowWidth * mouseXPosition / currWindowSize[0] - 0.5 * windowWidth;
	    GLfloat y = 0.5 * windowHeight - (windowHeight * mouseYPosition / currWindowSize[1]);

        if (!removePoint(x, y, objects))
            objects.push_back(new AnimatedPoint(x, y, Color(1.0, 0.0, 0.0), &rnd));
	}
}

void handleKeyEvent(unsigned char pressedKey, int mouseXPosition, int mouseYPosition) {
    switch(pressedKey) {
        case 'R': case 'r': objects.clear();
                            break;
        case 'V': case 'v': IS_POINTS_VISIBLE = !IS_POINTS_VISIBLE;
                            break;
        case 'L': case 'l': IS_LINES_VISIBLE = !IS_LINES_VISIBLE;
                            break;
        case 'A': case 'a': IS_POINTS_ANIMATED = !IS_POINTS_ANIMATED;
                            break;
        case 'H': case 'h': IS_HULL_VISIBLE = !IS_HULL_VISIBLE;
                            break;
    }
}

void TimerFunction(int value) {
    if (IS_POINTS_ANIMATED) {
        for (ptIter iter = objects.begin(); iter != objects.end(); ++iter)
            (*iter)->tick();
    }

    //for (ptIter iter = objects.begin(); iter != objects.end(); ++iter)
    //    (*iter)->isDupe = false;

    polar.setPole(getLowestPoint(objects));
    sort(objects.begin(), objects.end(), polar);
    
    Display();

    glutPostRedisplay();
    glutTimerFunc(30, TimerFunction, 1);
}

void doHull() {
    if (objects.size() < 3)
        return;

    PointStack S;
    for (int i = 0; i < 3; ++i)
        S.push(objects[i]);

    for (int i = 3; i < objects.size(); ++i) {
        while (!isLeftTurn(S.underTop(), S.top(), objects[i]))
            S.pop();
        S.push(objects[i]);
    }
    glColor3f(0.0, 0.5, 1.0);
    if (IS_POINTS_ANIMATED)
        glBegin(GL_TRIANGLE_FAN);
    else
        glBegin(GL_LINE_LOOP);

        while (S.size() != 0) {
            glVertex2d(S.top()->X(), S.top()->Y());
            S.pop();
        }
    glEnd();
}

bool isLeftTurn(Point *a, Point *b, Point *c) {
    GLfloat val = (a->X() - b->X()) * (c->Y() - b->Y()) -
                  (c->X() - b->X()) * (a->Y() - b->Y());
    return (val < 0);
}

void Display() {
	glClear(GL_COLOR_BUFFER_BIT);
    
    glPushMatrix();
        if (IS_HULL_VISIBLE)
            doHull();
        if (IS_LINES_VISIBLE) {
            glColor3f(1.0, 1.0, 0.0);
            glBegin(GL_LINES);
                for (ptIter iter = objects.begin(); iter != objects.end(); ++iter) {
                    glVertex2d((*objects.begin())->X(), (*objects.begin())->Y());
                    glVertex2d((*iter)->X(), (*iter)->Y());
                }
            glEnd();
        }
        if (IS_POINTS_VISIBLE) {
            for (ptIter iter = objects.begin(); iter != objects.end(); ++iter)
                (*iter)->draw();
        }
    glPopMatrix();

	glutSwapBuffers();
	glFlush();
}

void ResizeWindow(GLsizei w, GLsizei h) {
	glViewport(0, 0, w, h);
	currWindowSize[0] = w;
	currWindowSize[1] = h;
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    if (w <= h) {
		windowWidth = 2.0;
		windowHeight = 2.0 * (GLfloat)h / (GLfloat)w;
        glOrtho(-1.0, 1.0, -1.0 * (GLfloat)h / (GLfloat)w, (GLfloat)h / (GLfloat)w, -10.0, 10.0);
	}
	else {
		windowWidth = 2.0 * (GLfloat)w / (GLfloat)h;
		windowHeight = 2.0;
        glOrtho(-1.0 * (GLfloat)w / (GLfloat)h, (GLfloat)w / (GLfloat)h, -1.0, 1.0, -10.0, 10.0);
	}
    glMatrixMode(GL_MODELVIEW);
}